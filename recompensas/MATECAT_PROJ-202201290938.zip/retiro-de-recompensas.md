# ❗ Rewards Withdrawal

The Crypto One Rewards or earnings withdrawal system will be staggered every 7 days (Weekly Claim), it will be limited to the fact that you will have to withdraw 100% of your earnings each time.

**Notice: If you do not withdraw 100% of your profit on day 7, the system will penalize you as follows:**

* On day 8 the claim button will not have any function, but after 7 more days.
* On day 14 the system will allow you to withdraw only 50% of your accumulated earnings and so on until the following claims.

****





