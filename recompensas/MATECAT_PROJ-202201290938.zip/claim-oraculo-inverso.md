# 👑 Claim (Reverse Oracle)

This section will be the most important one since its mission will be to ensure that your game balance is similar at the time of withdrawing your rewards. This means your balance will be reflected in Dollars and at the time of withdrawal you will be given an equivalent amount in **$**CONE tokens:

| Token Price | Amount of dollars at stake | Equivalent amount of Tokens | Amount of Profit received with the Oracle |
| :---------------: | :--------------------------: | :----------------------------: | :------------------------------------------: |
| 10$ | 100$ | $10 $CONE | 100$ |
| 100$ | 100$ | 1 $CONE | 100$ |
